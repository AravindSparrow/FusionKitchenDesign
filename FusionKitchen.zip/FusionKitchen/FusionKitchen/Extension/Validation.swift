//
//  Validation.swift
//  FusionKitchen
//
//  Created by Aravind on 07/03/22.
//

import Foundation
import UIKit

extension String {
    var isPhonenumberValid : Bool {
        do {
            let detector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.phoneNumber.rawValue)
            let matches = detector.matches(in: self, options: [], range: NSMakeRange(0, self.count))
            if let res = matches.first {
                return res.resultType == .phoneNumber && res.range.location == 0 && res.range.length == self.count && self.count == 10
            } else{
                return false
            }
        } catch {
            return false
        }
    }
    
    var isValidEmail: Bool{
         let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
         let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
         return emailTest.evaluate(with: self)
     }
    
    var isValidUserName: Bool{
        let UserNameRegEx = "^[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*$"
        let UserNameTest = NSPredicate(format: "SELF MATCHES %@", UserNameRegEx)
        return UserNameTest.evaluate(with: self)
    }
    
    var isPasswordHasEightCharacter: Bool {
        let passWordRegEx = "^.{8,16}$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passWordRegEx)
        return passwordTest.evaluate(with: self)
    }

    var isPasswordHasOnelowercase: Bool {
        let passRegEx = "(?=.*[A-Z])(?=.*[a-z]).{8,16}"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passRegEx)
        return passwordTest.evaluate(with: self)
    }

    var isPasswordHasUppercaseLowerCaseOneNumber: Bool {
        let passWordRegEx = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"
//        let passWordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,16}"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passWordRegEx)
        return passwordTest.evaluate(with: self)
    }
    
    var isPasswordHasUppercaseLowerCaseOneNumberCharacter: Bool {
        let passWordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{8,16}"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passWordRegEx)
        return passwordTest.evaluate(with: self)
    }
    
}


extension String {
 func processDate(string: String, fromFormat: String, toFormat: String) -> String? {
  let formatter = DateFormatter()
  formatter.dateFormat = fromFormat
  guard let date = formatter.date(from: string) else { return nil }
  formatter.dateFormat = toFormat
  return formatter.string(from: date)
 }
}
//
