//
//  textViewCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit
import SkyFloatingLabelTextField

class textViewCell: UICollectionViewCell {
    
    static let identifier = "textViewCell"
    static let nib = UINib(nibName: "textViewCell", bundle: nil)
    
    @IBOutlet weak var applicationTextField: SkyFloatingLabelTextFieldWithIcon!
    @IBOutlet weak var forgotLbl: UILabel!
    @IBOutlet weak var loginImag: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func usernameConfiger() {
        applicationTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: applicationTextField.frame.height))
        applicationTextField.leftViewMode = .always
        loginImag.image = UIImage(named: "Icon simple-email")
        forgotLbl.isHidden = true
        applicationTextField.placeholder = " Email ID"
    }
    
    func passwordConfiger() {
        applicationTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: applicationTextField.frame.height))
        applicationTextField.leftViewMode = .always
        loginImag.image = UIImage(named: "Icon material-lock-outline")
        forgotLbl.isHidden = false
        applicationTextField.placeholder = "  Password"
    }

}
