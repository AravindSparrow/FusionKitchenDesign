//
//  HomeViewCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class HomeViewCell: UICollectionViewCell {
    
    static let identifier = "HomeViewCell"
    static let nib = UINib(nibName: "HomeViewCell", bundle: nil)
    
    @IBOutlet weak var shadowView: UIView!
    @IBOutlet weak var productImg: UIImageView!
    @IBOutlet weak var offerlbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var subtitlelbl: UILabel!
    @IBOutlet weak var ratingLbl: UILabel!
    @IBOutlet weak var statuslbl: UILabel!
    @IBOutlet weak var ratingImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.productImg.layer.masksToBounds = true
        self.productImg.layer.cornerRadius = 10
        self.shadowView.layer.cornerRadius = 5
        
        self.offerlbl.clipsToBounds = true
        self.offerlbl.layer.cornerRadius = 10
        self.offerlbl.layer.maskedCorners = [.layerMaxXMaxYCorner ,.layerMaxXMinYCorner]
    }
    
}
