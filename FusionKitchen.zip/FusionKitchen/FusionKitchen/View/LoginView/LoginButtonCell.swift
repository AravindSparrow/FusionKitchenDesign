//
//  LoginButtonCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class LoginButtonCell: UICollectionViewCell {
    
    static let identifier = "LoginButtonCell"
    static let nib = UINib(nibName: "LoginButtonCell", bundle: nil)
    
    @IBOutlet weak var loginBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}



