//
//  TitleViewCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class TitleViewCell: UICollectionViewCell {
    
    static let identifier = "TitleViewCell"
    static let nib = UINib(nibName: "TitleViewCell", bundle: nil)
    
    @IBOutlet weak var signupLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
