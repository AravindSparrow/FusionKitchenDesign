//
//  ApplicationTextCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit
import SkyFloatingLabelTextField

class ApplicationTextCell: UICollectionViewCell, UITextFieldDelegate {
    
    static let identifier = "ApplicationTextCell"
    static let nib = UINib(nibName: "ApplicationTextCell", bundle: nil)
    
    @IBOutlet weak var emailTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var passwordtextField: SkyFloatingLabelTextField!
    @IBOutlet weak var conformTextField: SkyFloatingLabelTextField!
    @IBOutlet weak var forgotLbl: UILabel!
    
    @IBOutlet weak var emailImg: UIImageView!
    @IBOutlet weak var passwordImg: UIImageView!
    @IBOutlet weak var conformImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code    }
    
    }
    func signUpConfiger() {
        
        NSAttributedString(string: "    Email ID", attributes: [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)])
        emailTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 13, height: emailTextField.frame.height))
        emailTextField.leftViewMode = .always
        
        NSAttributedString(string: "    Password", attributes: [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)])
        passwordtextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 13, height: passwordtextField.frame.height))
        passwordtextField.leftViewMode = .always
        
        NSAttributedString(string: "Phone Number", attributes: [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)])
        conformTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 13, height: conformTextField.frame.height))
        conformTextField.leftViewMode = .always
        
        emailTextField.placeholder = "   First Name"
        passwordtextField.placeholder = "   last Name"
        conformTextField.placeholder = "   Phone Numbers"
        
        forgotLbl.isHidden = true
        
        emailImg.image = UIImage(named: "user (4)")
        passwordImg.image = UIImage(named: "user (4)")
        conformImg.image = UIImage(named: "smartphone")
    }
    
    func signUpTwoConfiger() {
        
        NSAttributedString(string: "    Email ID", attributes: [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)])
        emailTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 13, height: emailTextField.frame.height))
        emailTextField.leftViewMode = .always
        
        NSAttributedString(string: "    Password", attributes: [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)])
        passwordtextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 13, height: passwordtextField.frame.height))
        passwordtextField.leftViewMode = .always
        
        NSAttributedString(string: "Phone Number", attributes: [NSAttributedString.Key.foregroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)])
        conformTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 13, height: conformTextField.frame.height))
        conformTextField.leftViewMode = .always
        
        emailTextField.placeholder = "   Email Id"
        passwordtextField.placeholder = "   New Password"
        conformTextField.placeholder = "   Confirm Password"
        
        forgotLbl.isHidden = true
        
        emailImg.image = UIImage(named: "Icon simple-email")
        passwordImg.image = UIImage(named: "Icon material-lock-outline")
        conformImg.image = UIImage(named: "Icon material-lock-outline")
    }
}



