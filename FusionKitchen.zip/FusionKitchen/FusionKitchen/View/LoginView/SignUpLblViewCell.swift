//
//  SignUpLblViewCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class SignUpLblViewCell: UICollectionViewCell {
    
    static let identifier = "SignUpLblViewCell"
    static let nib = UINib(nibName: "SignUpLblViewCell", bundle: nil)
    
    @IBOutlet weak var signUpBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}


