//
//  NextButtonViewCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class NextButtonViewCell: UICollectionViewCell {
    
    static let identifier = "NextButtonViewCell"
    static let nib = UINib(nibName: "NextButtonViewCell", bundle: nil)
    
    @IBOutlet weak var nextBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
//        let stencil = UIImage(named: "Icon feather-arrow-right")?.withRenderingMode(.alwaysTemplate)
//        nextBtn.setImage(stencil, for: .normal)
        nextBtn.layer.cornerRadius = 10
    }

}
