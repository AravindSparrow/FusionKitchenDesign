//
//  SinginImageCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class SinginImageCell: UICollectionViewCell {
    
    static let identifier = "SinginImageCell"
    static let nib = UINib(nibName: "SinginImageCell", bundle: nil)
    
    @IBOutlet weak var headerImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}



