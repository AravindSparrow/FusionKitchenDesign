//
//  SOSViewCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class SOSViewCell: UICollectionViewCell {
    
    static let identifier = "SOSViewCell"
    static let nib = UINib(nibName: "SOSViewCell", bundle: nil)
    
    @IBOutlet weak var googleBtn: UIButton!
    @IBOutlet weak var faceBookbtn: UIButton!
    @IBOutlet weak var appleBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func sosConfiger() {
        googleBtn.layer.cornerRadius = 8
        faceBookbtn.layer.cornerRadius = 8
        appleBtn.layer.cornerRadius = 8
        googleBtn.layer.borderWidth = 1
        faceBookbtn.layer.borderWidth = 1
        appleBtn.layer.borderWidth = 1
        googleBtn.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        faceBookbtn.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        appleBtn.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        googleBtn.layer.masksToBounds = true
        faceBookbtn.layer.masksToBounds = true
        appleBtn.layer.masksToBounds = true
    }

}



