//
//  SOSLblCell.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class SOSLblCell: UICollectionViewCell {
    
    static let identifier = "SOSLblCell"
    static let nib = UINib(nibName: "SOSLblCell", bundle: nil)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}



