//
//  ForgotVC.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class ForgotVC: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}
