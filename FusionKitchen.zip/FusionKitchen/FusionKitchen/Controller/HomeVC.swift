//
//  HomeVC.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class HomeVC: UIViewController {
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var homeCollectionView: UICollectionView! {
        didSet {
            homeCollectionView.delegate = self
            homeCollectionView.dataSource = self
            homeCollectionView.register(HomeViewCell.nib, forCellWithReuseIdentifier: HomeViewCell.identifier)
        }
    }
    
    var imageArray = [ UIImage(named: "ImageOne"), UIImage(named: "ImageTwo"), UIImage(named: "ImageTwo"), UIImage(named: "ImageOne") ]
    var titleArray = ["Ragam", "Oiishi Sushi", "Ragam", "Oiishi Sushi"]
    var subtitle = ["Indian, Kerala, Pizza", "Indian, Kerala, Pizza", "Indian, Kerala, Pizza", "Indian, Kerala, Pizza"]
    var ratingArray = [ "Pre-Order" ,"Open" ,"Takeaway" ,"Pre-Order" ]
    var offerARRAY = ["10% OFF", "20% OFF", "5% OFF", "10% OFF"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.loginBtn.layer.cornerRadius = 5
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.showToast(message: "Wellcome", font: .systemFont(ofSize: 12.0))
    }
    
    @IBAction func tappedOnLoginPage(_ sender: Any) {
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let nVC = mainStoryBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        let navController = UINavigationController(rootViewController: nVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
}

extension HomeVC: UICollectionViewDelegate , UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = homeCollectionView.dequeueReusableCell(withReuseIdentifier: HomeViewCell.identifier, for: indexPath) as! HomeViewCell
        cell.productImg.image = imageArray[indexPath.item]
        cell.titleLbl.text = titleArray[indexPath.item]
        cell.subtitlelbl.text = titleArray[indexPath.item]
        cell.statuslbl.text = ratingArray[indexPath.item]
        cell.offerlbl.text = offerARRAY[indexPath.item]
        return cell
    }
    
}

extension HomeVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width / 2 , height: 200
        )
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
}

extension UIViewController {

func showToast(message : String, font: UIFont) {

    let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
    toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    toastLabel.textColor = UIColor.white
    toastLabel.font = font
    toastLabel.textAlignment = .center;
    toastLabel.text = message
    toastLabel.alpha = 1.0
    toastLabel.layer.cornerRadius = 10;
    toastLabel.clipsToBounds  =  true
    self.view.addSubview(toastLabel)
    UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
         toastLabel.alpha = 0.0
    }, completion: {(isCompleted) in
        toastLabel.removeFromSuperview()
    })
} }
