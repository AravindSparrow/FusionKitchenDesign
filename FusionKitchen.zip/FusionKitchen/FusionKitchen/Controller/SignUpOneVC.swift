//
//  SignUpOneVC.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class SignUpOneVC: UIViewController {
    
    @IBOutlet weak var signUpOneCollectionView: UICollectionView! {
        didSet {
            signUpOneCollectionView.delegate = self
            signUpOneCollectionView.dataSource = self
            signUpOneCollectionView.register(SinginImageCell.nib, forCellWithReuseIdentifier: SinginImageCell.identifier)
            signUpOneCollectionView.register(TitleViewCell.nib, forCellWithReuseIdentifier: TitleViewCell.identifier)
            signUpOneCollectionView.register(SOSViewCell.nib, forCellWithReuseIdentifier: SOSViewCell.identifier)
            signUpOneCollectionView.register(SOSLblCell.nib, forCellWithReuseIdentifier: SOSLblCell.identifier)
            signUpOneCollectionView.register(ApplicationTextCell.nib, forCellWithReuseIdentifier: ApplicationTextCell.identifier)
            signUpOneCollectionView.register(NextButtonViewCell.nib, forCellWithReuseIdentifier: NextButtonViewCell.identifier)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
    }
    
    //Tappen On Next
    @objc func nextButton() {
        let mainStoryBoard = UIStoryboard(name: "SignUpVC", bundle: nil)
        let nVC = mainStoryBoard.instantiateViewController(withIdentifier: "SignUPTwoVC") as! SignUPTwoVC
        let navController = UINavigationController(rootViewController: nVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
    
}

extension SignUpOneVC: UICollectionViewDelegate , UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch indexPath.item {
        case 0:
            let cell = signUpOneCollectionView.dequeueReusableCell(withReuseIdentifier: SinginImageCell.identifier, for: indexPath) as! SinginImageCell
            cell.headerImg.image = UIImage(named: "Group 16172")
            return cell
        case 1:
            let cell = signUpOneCollectionView.dequeueReusableCell(withReuseIdentifier: TitleViewCell.identifier, for: indexPath) as! TitleViewCell
            cell.signupLbl.text = "Sign Up"
            return cell
        case 2:
            let cell = signUpOneCollectionView.dequeueReusableCell(withReuseIdentifier: SOSViewCell.identifier, for: indexPath) as! SOSViewCell
            cell.sosConfiger()
            return cell
        case 3:
            let cell = signUpOneCollectionView.dequeueReusableCell(withReuseIdentifier: SOSLblCell.identifier, for: indexPath) as! SOSLblCell
            return cell
        case 4:
            let cell = signUpOneCollectionView.dequeueReusableCell(withReuseIdentifier: ApplicationTextCell.identifier, for: indexPath) as! ApplicationTextCell
            cell.signUpConfiger()
            return cell
        case 5:
            let cell = signUpOneCollectionView.dequeueReusableCell(withReuseIdentifier: NextButtonViewCell.identifier, for: indexPath) as! NextButtonViewCell
            let tapAction = UITapGestureRecognizer(target: self, action: #selector(nextButton))
            cell.nextBtn?.isUserInteractionEnabled = true
            cell.nextBtn?.addGestureRecognizer(tapAction)
            return cell
        default:
            return UICollectionViewCell()
        }
        
    }
    
}

extension SignUpOneVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch indexPath.item {
        case 0:
            return CGSize(width: UIScreen.main.bounds.width, height: 200)
        case 1:
            return CGSize(width: UIScreen.main.bounds.width, height: 20)
        case 2:
            return CGSize(width: UIScreen.main.bounds.width, height: 60)
        case 3:
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        case 4:
            return CGSize(width: UIScreen.main.bounds.width, height: 180)
        case 5:
            return CGSize(width: UIScreen.main.bounds.width, height: 110)
        default:
            return CGSize(width: 0, height: 0)
        }
    }
}
