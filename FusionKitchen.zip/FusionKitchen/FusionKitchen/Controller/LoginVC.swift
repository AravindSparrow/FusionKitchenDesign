//
//  LoginVC.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class LoginVC: UIViewController {
    
    @IBOutlet weak var loginCollectionView: UICollectionView! {
        didSet {
            loginCollectionView.delegate = self
            loginCollectionView.dataSource = self
            loginCollectionView.register(SinginImageCell.nib, forCellWithReuseIdentifier: SinginImageCell.identifier)
            loginCollectionView.register(textViewCell.nib, forCellWithReuseIdentifier: textViewCell.identifier)
            loginCollectionView.register(SOSViewCell.nib, forCellWithReuseIdentifier: SOSViewCell.identifier)
            loginCollectionView.register(SOSLblCell.nib, forCellWithReuseIdentifier: SOSLblCell.identifier)
            loginCollectionView.register(LoginButtonCell.nib, forCellWithReuseIdentifier: LoginButtonCell.identifier)
            loginCollectionView.register(SignUpLblViewCell.nib, forCellWithReuseIdentifier: SignUpLblViewCell.identifier)
            loginCollectionView.register(TitleViewCell.nib, forCellWithReuseIdentifier: TitleViewCell.identifier)
            
        }
    }
        
    var userName = String()
    var password = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    // Tapped On Login button
    @objc func loginButton() {
        
        if (userName.isEmpty) {
            displayErrorMessage(title: "Error", message: "Please enter your Email", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
            }])
        } else if userName.isValidEmail == false {
            displayErrorMessage(title: "Error", message: "Please enter Valid Email", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
            }])
        } else  if (password.isEmpty) {
            displayErrorMessage(title: "Error", message: "Please enter your Password", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
            }])
        } else if password.isPasswordHasEightCharacter == false {
            displayErrorMessage(title: "Error", message: " Please enter atleast Minimum 8 characters", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
            }])
        } else if password.isPasswordHasOnelowercase == false {
            displayErrorMessage(title: "Error", message: "Please enter atleast One Uppercase", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
            }])
//        } else if password.isPasswordHasUppercaseLowerCaseOneNumber == false {
//            displayErrorMessage(title: "Error", message: "Please enter atleast One Number", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
//            }])
        } else if password.isPasswordHasUppercaseLowerCaseOneNumberCharacter == false {
            displayErrorMessage(title: "Error", message: "Please enter atleast One Special Character", alertStyle: .alert, actionTitles: ["Okay"], actionStyles: [.default], actions: [{ _ in
            }])
        } else {
            self.HomeScreen()
        }
        
    }
    
    
    func HomeScreen() {
        let mainStoryBoard = UIStoryboard(name: "HomeVC", bundle: nil)
        let nVC = mainStoryBoard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        let navController = UINavigationController(rootViewController: nVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
    
    // TApped On Forgot Password
    @objc func tappedForgotPassword() {
//        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
//        let nVC = mainStoryBoard.instantiateViewController(withIdentifier: "ForgotVC") as! ForgotVC
//        let navController = UINavigationController(rootViewController: nVC)
//        navController.modalPresentationStyle = .fullScreen
//        self.present(navController, animated:true, completion: nil)
    }
    
    // TApped On Sign Up
    @objc func tappedForgotSignUP() {
        let mainStoryBoard = UIStoryboard(name: "SignUpVC", bundle: nil)
        let nVC = mainStoryBoard.instantiateViewController(withIdentifier: "SignUpOneVC") as! SignUpOneVC
        let navController = UINavigationController(rootViewController: nVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
    
    @objc func textDidChange(textField: UITextField) {
        guard let cell = textField.superview?.superview as? textViewCell,
              let collection = cell.superview as? UICollectionView,
              let indexPath = collection.indexPath(for: cell) else { return }
        switch indexPath.item {
        case 2: userName = textField.text!
        case 3: password = textField.text!
        default: break
        }
    }
    
}

extension LoginVC: UICollectionViewDelegate , UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch indexPath.item {
        case 0:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: SinginImageCell.identifier, for: indexPath) as! SinginImageCell
            return cell
        case 1:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: TitleViewCell.identifier, for: indexPath) as! TitleViewCell
            return cell
        case 2:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: textViewCell.identifier, for: indexPath) as! textViewCell
            cell.usernameConfiger()
            cell.applicationTextField.tag = indexPath.item
            cell.applicationTextField.addTarget(self, action: #selector(self.textDidChange(textField:)), for: .editingChanged)
            return cell
        case 3:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: textViewCell.identifier, for: indexPath) as! textViewCell
            cell.passwordConfiger()
            cell.applicationTextField.tag = indexPath.item
            cell.applicationTextField.addTarget(self, action: #selector(self.textDidChange(textField:)), for: .editingChanged)
            return cell
        case 4:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: LoginButtonCell.identifier, for: indexPath) as! LoginButtonCell
            cell.loginBtn.layer.cornerRadius = 10
            cell.loginBtn.addTarget(self, action: #selector(loginButton), for: .touchUpInside)
            return cell
        case 5:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: SOSLblCell.identifier, for: indexPath) as! SOSLblCell
            return cell
        case 6:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: SOSViewCell.identifier, for: indexPath) as! SOSViewCell
            cell.sosConfiger()
            return cell
        case 7:
            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: SignUpLblViewCell.identifier, for: indexPath) as! SignUpLblViewCell
            let tapAction = UITapGestureRecognizer(target: self, action: #selector(tappedForgotSignUP))
            cell.signUpBtn?.isUserInteractionEnabled = true
            cell.signUpBtn?.addGestureRecognizer(tapAction)
            return cell
        default:
            return UICollectionViewCell()
        }
        
    }
    
}

extension LoginVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch indexPath.item {
        case 0:
            return CGSize(width: UIScreen.main.bounds.width, height: 250)
        case 1:
            return CGSize(width: UIScreen.main.bounds.width, height: 30)
        case 2:
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        case 3:
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        case 4:
            return CGSize(width: UIScreen.main.bounds.width, height: 70)
        case 5:
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        case 6:
            return CGSize(width: UIScreen.main.bounds.width, height: 100)
        case 7:
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        default:
            return CGSize(width: 0, height: 0)
        }
    }
}
//            let cell = loginCollectionView.dequeueReusableCell(withReuseIdentifier: ApplicationTextCell.identifier, for: indexPath) as! ApplicationTextCell
//            cell.loginConfiger()
//            cell.userNamedelegate = self
//            cell.passworddelegate = self
//            let tapAction = UITapGestureRecognizer(target: self, action: #selector(tappedForgotPassword))
//            cell.forgotLbl?.isUserInteractionEnabled = true
//            cell.forgotLbl?.addGestureRecognizer(tapAction)
//            return cell
