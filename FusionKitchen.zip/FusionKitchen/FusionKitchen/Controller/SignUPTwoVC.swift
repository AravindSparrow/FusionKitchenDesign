//
//  SignUPTwoVC.swift
//  FusionKitchen
//
//  Created by Aravind on 06/03/22.
//

import UIKit

class SignUPTwoVC: UIViewController {
    
    @IBOutlet weak var signupTwoCollectionView: UICollectionView! {
        didSet {
            signupTwoCollectionView.delegate = self
            signupTwoCollectionView.dataSource = self
            signupTwoCollectionView.register(SinginImageCell.nib, forCellWithReuseIdentifier: SinginImageCell.identifier)
            signupTwoCollectionView.register(TitleViewCell.nib, forCellWithReuseIdentifier: TitleViewCell.identifier)
            signupTwoCollectionView.register(SOSViewCell.nib, forCellWithReuseIdentifier: SOSViewCell.identifier)
            signupTwoCollectionView.register(SOSLblCell.nib, forCellWithReuseIdentifier: SOSLblCell.identifier)
            signupTwoCollectionView.register(ApplicationTextCell.nib, forCellWithReuseIdentifier: ApplicationTextCell.identifier)
            signupTwoCollectionView.register(NextButtonViewCell.nib, forCellWithReuseIdentifier: NextButtonViewCell.identifier)
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
    }
    
    //Tappen On Next
    @objc func nextButton() {
        let mainStoryBoard = UIStoryboard(name: "HomeVC", bundle: nil)
        let nVC = mainStoryBoard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        let navController = UINavigationController(rootViewController: nVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
    
}

extension SignUPTwoVC: UICollectionViewDelegate , UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch indexPath.item {
        case 0:
            let cell = signupTwoCollectionView.dequeueReusableCell(withReuseIdentifier: SinginImageCell.identifier, for: indexPath) as! SinginImageCell
            cell.headerImg.image = UIImage(named: "Group 16172")
            return cell
        case 1:
            let cell = signupTwoCollectionView.dequeueReusableCell(withReuseIdentifier: TitleViewCell.identifier, for: indexPath) as! TitleViewCell
            cell.signupLbl.text = "Sign Up"
            return cell
        case 2:
            let cell = signupTwoCollectionView.dequeueReusableCell(withReuseIdentifier: SOSViewCell.identifier, for: indexPath) as! SOSViewCell
            cell.sosConfiger()
            return cell
        case 3:
            let cell = signupTwoCollectionView.dequeueReusableCell(withReuseIdentifier: SOSLblCell.identifier, for: indexPath) as! SOSLblCell
            return cell
        case 4:
            let cell = signupTwoCollectionView.dequeueReusableCell(withReuseIdentifier: ApplicationTextCell.identifier, for: indexPath) as! ApplicationTextCell
            cell.signUpTwoConfiger()
            return cell
        case 5:
            let cell = signupTwoCollectionView.dequeueReusableCell(withReuseIdentifier: NextButtonViewCell.identifier, for: indexPath) as! NextButtonViewCell
            let tapAction = UITapGestureRecognizer(target: self, action: #selector(nextButton))
            cell.nextBtn?.isUserInteractionEnabled = true
            cell.nextBtn?.addGestureRecognizer(tapAction)
            return cell
        default:
            return UICollectionViewCell()
        }
        
    }
    
}

extension SignUPTwoVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch indexPath.item {
        case 0:
            return CGSize(width: UIScreen.main.bounds.width, height: 200)
        case 1:
            return CGSize(width: UIScreen.main.bounds.width, height: 20)
        case 2:
            return CGSize(width: UIScreen.main.bounds.width, height: 60)
        case 3:
            return CGSize(width: UIScreen.main.bounds.width, height: 50)
        case 4:
            return CGSize(width: UIScreen.main.bounds.width, height: 180)
        case 5:
            return CGSize(width: UIScreen.main.bounds.width, height: 110)
        default:
            return CGSize(width: 0, height: 0)
        }
    }
}
